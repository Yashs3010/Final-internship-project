![image](https://user-images.githubusercontent.com/58760825/172065293-c2868dbc-180f-442f-b985-d9b445c3cb69.png)


# ToDo
> Android application to save user tasks to help having a productive day<br>
> [Click Here](https://drive.google.com/file/d/1dnc-bI79VeHhTwYlA3EKYbE-o1yUqieT/view?usp=sharing) to download apk for testing

# Features
> Users can save as many tasks as they want  <br>
> Simple and easy to use  <br>
> Users can prioritize a task from Low - Medium – High <br>
> User can set the due time if due time crosses the task will be marked as missed <br>

# Upcomming Features:  
> Task filter  <br>
> Task arranged in category  <br>
> Task view  <br>
> -- Linear<br>
> -- Grid<br>
> Task view item color change on the bases of due time <br>
> Users will get alert notifications if the due time of a task is near <br>


# Tech Stack: 
> Kotlin <br>
> Android Studio<br>
>  LottieFiles – for animated arts<br>
>  Room database <br>

 
